
import React, { useState, useEffect, useRef } from 'react';

const WordWiggleGame = () => {
  // Word categories with different difficulty levels
  const wordCategories = {
    easy: {
      name: "Easy Words (3-4 letters)",
      words: [
        { word: "CAT", hint: "Furry pet that meows", audio: "cat" },
        { word: "DOG", hint: "Loyal pet that barks", audio: "dog" },
        { word: "SUN", hint: "Bright star in the sky", audio: "sun" },
        { word: "HAT", hint: "Wear it on your head", audio: "hat" },
        { word: "BED", hint: "Where you sleep", audio: "bed" },
        { word: "FISH", hint: "Swims in water", audio: "fish" },
        { word: "BOOK", hint: "Read stories from this", audio: "book" },
        { word: "BIRD", hint: "Flies in the sky", audio: "bird" }
      ]
    },
    medium: {
      name: "Medium Words (5-6 letters)",
      words: [
        { word: "HAPPY", hint: "Feeling joyful", audio: "happy" },
        { word: "FLOWER", hint: "Beautiful plant that blooms", audio: "flower" },
        { word: "SMILE", hint: "Happy expression on your face", audio: "smile" },
        { word: "WATER", hint: "Clear liquid we drink", audio: "water" },
        { word: "FRIEND", hint: "Someone you like to play with", audio: "friend" },
        { word: "SCHOOL", hint: "Where you go to learn", audio: "school" },
        { word: "FAMILY", hint: "People who love you at home", audio: "family" }
      ]
    },
    hard: {
      name: "Hard Words (7+ letters)",
      words: [
        { word: "RAINBOW", hint: "Colorful arc in the sky", audio: "rainbow" },
        { word: "ELEPHANT", hint: "Large animal with a trunk", audio: "elephant" },
        { word: "BUTTERFLY", hint: "Colorful flying insect", audio: "butterfly" },
        { word: "ADVENTURE", hint: "Exciting journey or experience", audio: "adventure" },
        { word: "BEAUTIFUL", hint: "Very pretty or lovely", audio: "beautiful" }
      ]
    }
  };

  // Game state
  const [currentCategory, setCurrentCategory] = useState('easy');
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [playerWord, setPlayerWord] = useState([]);
  const [availableLetters, setAvailableLetters] = useState([]);
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [isCorrect, setIsCorrect] = useState(false);
  const [gameComplete, setGameComplete] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [highContrast, setHighContrast] = useState(false);
  const [fontSize, setFontSize] = useState('text-2xl');

  // Audio ref for pronunciation
  const audioRef = useRef(null);

  // Get current word
  const getCurrentWord = () => {
    return wordCategories[currentCategory].words[currentWordIndex];
  };

  // Shuffle array function
  const shuffleArray = (array) => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  // Initialize game
  const initializeGame = () => {
    const word = getCurrentWord().word;
    const letters = word.split('');
    setAvailableLetters(shuffleArray(letters));
    setPlayerWord(new Array(word.length).fill(''));
    setShowHint(false);
    setFeedback('');
    setIsCorrect(false);
    setAttempts(0);
  };

  // Text-to-speech function
  const speakText = (text) => {
    if (audioEnabled && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1.1;
      utterance.volume = 0.8;
      speechSynthesis.speak(utterance);
    }
  };

  // Handle letter click
  const handleLetterClick = (letter, index) => {
    const emptyIndex = playerWord.findIndex(slot => slot === '');
    if (emptyIndex !== -1) {
      const newPlayerWord = [...playerWord];
      newPlayerWord[emptyIndex] = letter;
      setPlayerWord(newPlayerWord);
      
      const newAvailableLetters = [...availableLetters];
      newAvailableLetters[index] = '';
      setAvailableLetters(newAvailableLetters);
    }
  };

  // Handle word slot click (remove letter)
  const handleSlotClick = (slotIndex) => {
    if (playerWord[slotIndex] !== '') {
      const letter = playerWord[slotIndex];
      const newPlayerWord = [...playerWord];
      newPlayerWord[slotIndex] = '';
      setPlayerWord(newPlayerWord);
      
      const emptyLetterIndex = availableLetters.findIndex(l => l === '');
      const newAvailableLetters = [...availableLetters];
      newAvailableLetters[emptyLetterIndex] = letter;
      setAvailableLetters(newAvailableLetters);
    }
  };

  // Check word
  const checkWord = () => {
    const currentWord = getCurrentWord().word;
    const playerWordString = playerWord.join('');
    
    if (playerWordString === currentWord) {
      setIsCorrect(true);
      setFeedback('🎉 Excellent! You got it right!');
      setScore(score + (currentCategory === 'easy' ? 10 : currentCategory === 'medium' ? 20 : 30));
      speakText('Excellent! You got it right!');
      
      setTimeout(() => {
        nextWord();
      }, 2000);
    } else {
      setAttempts(attempts + 1);
      if (attempts >= 2) {
        setShowHint(true);
        setFeedback('💡 Here\'s a hint to help you!');
        speakText('Here is a hint to help you');
      } else {
        setFeedback('🤔 Not quite right. Try again!');
        speakText('Not quite right. Try again!');
      }
    }
  };

  // Next word
  const nextWord = () => {
    const categoryWords = wordCategories[currentCategory].words;
    if (currentWordIndex < categoryWords.length - 1) {
      setCurrentWordIndex(currentWordIndex + 1);
    } else {
      setGameComplete(true);
      setFeedback('🏆 Congratulations! You completed all words!');
      speakText('Congratulations! You completed all words!');
    }
  };

  // Reset game
  const resetGame = () => {
    setCurrentWordIndex(0);
    setScore(0);
    setGameComplete(false);
    initializeGame();
  };

  // Change category
  const changeCategory = (category) => {
    setCurrentCategory(category);
    setCurrentWordIndex(0);
    setScore(0);
    setGameComplete(false);
  };

  // Initialize game when component mounts or category/word changes
  useEffect(() => {
    initializeGame();
  }, [currentCategory, currentWordIndex]);

  // Pronounce word
  const pronounceWord = () => {
    speakText(getCurrentWord().word);
  };

  if (gameComplete) {
    return (
      <div className={`max-w-4xl mx-auto p-6 ${highContrast ? 'bg-black text-yellow-300' : 'bg-gradient-to-br from-purple-100 to-pink-100'} rounded-2xl shadow-2xl min-h-screen flex flex-col items-center justify-center`}>
        <div className="text-center">
          <div className="text-6xl mb-4">🏆</div>
          <h1 className={`text-4xl font-bold mb-4 ${highContrast ? 'text-yellow-300' : 'text-purple-800'}`}>
            Congratulations!
          </h1>
          <p className={`text-2xl mb-6 ${highContrast ? 'text-white' : 'text-gray-700'}`}>
            You completed {wordCategories[currentCategory].name}!
          </p>
          <p className={`text-3xl font-bold mb-8 ${highContrast ? 'text-yellow-300' : 'text-green-600'}`}>
            Final Score: {score} points
          </p>
          <div className="space-x-4">
            <button
              onClick={resetGame}
              className={`px-8 py-4 rounded-full font-bold text-xl transition-all transform hover:scale-105 ${
                highContrast 
                  ? 'bg-yellow-300 text-black hover:bg-yellow-400' 
                  : 'bg-gradient-to-r from-green-400 to-green-600 text-white hover:from-green-500 hover:to-green-700'
              } shadow-lg`}
            >
              Play Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentWord = getCurrentWord();
  const isWordComplete = !playerWord.includes('');

  return (
    <div className={`max-w-4xl mx-auto p-6 ${highContrast ? 'bg-black text-white' : 'bg-gradient-to-br from-blue-50 to-indigo-100'} rounded-2xl shadow-2xl min-h-screen`}>
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className={`text-4xl font-bold mb-4 ${highContrast ? 'text-yellow-300' : 'text-indigo-800'} font-comic`}>
          🧠 WordWiggle: Read & Play!
        </h1>
        <div className={`text-lg ${highContrast ? 'text-white' : 'text-gray-600'}`}>
          Category: {wordCategories[currentCategory].name} | Score: {score} | Word {currentWordIndex + 1} of {wordCategories[currentCategory].words.length}
        </div>
      </div>

      {/* Settings Panel */}
      <div className={`mb-6 p-4 rounded-xl ${highContrast ? 'bg-gray-900' : 'bg-white'} shadow-lg`}>
        <div className="flex flex-wrap gap-4 items-center justify-center">
          {/* Category Selection */}
          <div className="flex gap-2">
            {Object.keys(wordCategories).map((category) => (
              <button
                key={category}
                onClick={() => changeCategory(category)}
                className={`px-4 py-2 rounded-full font-bold transition-all ${
                  currentCategory === category
                    ? (highContrast ? 'bg-yellow-300 text-black' : 'bg-indigo-600 text-white')
                    : (highContrast ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-gray-200 text-gray-700 hover:bg-gray-300')
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>

          {/* Accessibility Options */}
          <div className="flex gap-2 items-center">
            <button
              onClick={() => setAudioEnabled(!audioEnabled)}
              className={`px-3 py-2 rounded-full font-bold ${
                audioEnabled 
                  ? (highContrast ? 'bg-yellow-300 text-black' : 'bg-green-500 text-white')
                  : (highContrast ? 'bg-gray-700 text-white' : 'bg-gray-300 text-gray-700')
              }`}
            >
              🔊 {audioEnabled ? 'On' : 'Off'}
            </button>
            
            <button
              onClick={() => setHighContrast(!highContrast)}
              className={`px-3 py-2 rounded-full font-bold ${
                highContrast 
                  ? 'bg-yellow-300 text-black' 
                  : 'bg-gray-800 text-white'
              }`}
            >
              ⚫ High Contrast
            </button>
            
            <select
              value={fontSize}
              onChange={(e) => setFontSize(e.target.value)}
              className={`px-3 py-2 rounded-full font-bold ${
                highContrast ? 'bg-gray-700 text-white' : 'bg-white text-gray-700'
              }`}
            >
              <option value="text-xl">Small</option>
              <option value="text-2xl">Medium</option>
              <option value="text-3xl">Large</option>
            </select>
          </div>
        </div>
      </div>

      {/* Word Display Area */}
      <div className="text-center mb-8">
        <div className="flex justify-center items-center gap-4 mb-6">
          {playerWord.map((letter, index) => (
            <div
              key={index}
              onClick={() => handleSlotClick(index)}
              className={`w-16 h-16 border-4 border-dashed rounded-xl flex items-center justify-center cursor-pointer transition-all transform hover:scale-105 ${fontSize} font-bold ${
                letter 
                  ? (highContrast ? 'bg-yellow-300 text-black border-yellow-300' : 'bg-blue-500 text-white border-blue-500')
                  : (highContrast ? 'border-white bg-gray-800' : 'border-gray-400 bg-white hover:border-blue-300')
              }`}
            >
              {letter}
            </div>
          ))}
        </div>

        <button
          onClick={pronounceWord}
          className={`px-6 py-3 rounded-full font-bold text-lg mb-4 transition-all transform hover:scale-105 ${
            highContrast 
              ? 'bg-yellow-300 text-black hover:bg-yellow-400' 
              : 'bg-gradient-to-r from-purple-400 to-purple-600 text-white hover:from-purple-500 hover:to-purple-700'
          } shadow-lg`}
        >
          🔊 Hear the Word
        </button>
      </div>

      {/* Available Letters */}
      <div className="mb-8">
        <h3 className={`text-xl font-bold text-center mb-4 ${highContrast ? 'text-yellow-300' : 'text-indigo-700'}`}>
          Drag these letters to spell the word:
        </h3>
        <div className="flex justify-center gap-3 flex-wrap">
          {availableLetters.map((letter, index) => (
            <button
              key={index}
              onClick={() => letter && handleLetterClick(letter, index)}
              disabled={!letter}
              className={`w-14 h-14 rounded-xl font-bold text-2xl transition-all transform hover:scale-110 ${
                letter
                  ? (highContrast 
                      ? 'bg-white text-black hover:bg-gray-200 shadow-lg' 
                      : 'bg-gradient-to-br from-yellow-300 to-orange-400 text-gray-800 hover:from-yellow-400 hover:to-orange-500 shadow-lg')
                  : 'invisible'
              }`}
            >
              {letter}
            </button>
          ))}
        </div>
      </div>

      {/* Hint Section */}
      {showHint && (
        <div className={`mb-6 p-4 rounded-xl ${highContrast ? 'bg-gray-900' : 'bg-yellow-50 border-yellow-200 border-2'} text-center`}>
          <p className={`text-lg font-medium ${highContrast ? 'text-yellow-300' : 'text-yellow-800'}`}>
            💡 Hint: {currentWord.hint}
          </p>
        </div>
      )}

      {/* Feedback */}
      {feedback && (
        <div className={`text-center mb-6 p-4 rounded-xl ${
          isCorrect 
            ? (highContrast ? 'bg-green-900 text-green-200' : 'bg-green-100 text-green-800')
            : (highContrast ? 'bg-blue-900 text-blue-200' : 'bg-blue-100 text-blue-800')
        }`}>
          <p className="text-xl font-bold">{feedback}</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="text-center space-x-4">
        <button
          onClick={checkWord}
          disabled={!isWordComplete || isCorrect}
          className={`px-8 py-4 rounded-full font-bold text-xl transition-all transform hover:scale-105 ${
            isWordComplete && !isCorrect
              ? (highContrast 
                  ? 'bg-yellow-300 text-black hover:bg-yellow-400' 
                  : 'bg-gradient-to-r from-green-400 to-green-600 text-white hover:from-green-500 hover:to-green-700')
              : (highContrast ? 'bg-gray-700 text-gray-400' : 'bg-gray-300 text-gray-500 cursor-not-allowed')
          } shadow-lg`}
        >
          Check Word
        </button>

        <button
          onClick={initializeGame}
          className={`px-8 py-4 rounded-full font-bold text-xl transition-all transform hover:scale-105 ${
            highContrast 
              ? 'bg-gray-700 text-white hover:bg-gray-600' 
              : 'bg-gradient-to-r from-gray-400 to-gray-600 text-white hover:from-gray-500 hover:to-gray-700'
          } shadow-lg`}
        >
          New Letters
        </button>
      </div>

      {/* Progress Indicator */}
      <div className="mt-8">
        <div className={`w-full h-3 rounded-full ${highContrast ? 'bg-gray-800' : 'bg-gray-200'}`}>
          <div
            className={`h-3 rounded-full transition-all duration-500 ${
              highContrast ? 'bg-yellow-300' : 'bg-gradient-to-r from-blue-400 to-purple-600'
            }`}
            style={{
              width: `${((currentWordIndex + (isCorrect ? 1 : 0)) / wordCategories[currentCategory].words.length) * 100}%`
            }}
          />
        </div>
        <p className={`text-center mt-2 text-sm ${highContrast ? 'text-gray-400' : 'text-gray-600'}`}>
          Progress: {currentWordIndex + (isCorrect ? 1 : 0)} / {wordCategories[currentCategory].words.length} words
        </p>
      </div>
    </div>
  );
};

export default WordWiggleGame;
